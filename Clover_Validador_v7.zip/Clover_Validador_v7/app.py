import streamlit as st
import pandas as pd
from datetime import datetime
import os
import sys

# Añadir la carpeta 'app' al path
sys.path.append(os.path.join(os.path.dirname(__file__), 'app'))

# === 🔐 SISTEMA DE LOGIN ===
def login():
    st.title("🔐 Validador de Cobranzas Clover")

    # Cargar usuarios
    usuarios_file = os.path.join("data", "usuarios.csv")
    if not os.path.exists(usuarios_file):
        st.error("❌ No se encontró el archivo de usuarios.")
        return False

    df_usuarios = pd.read_csv(usuarios_file)

    st.subheader("Ingresá tus credenciales")
    usuario = st.text_input("Usuario")
    contrasena = st.text_input("Contraseña", type="password")

    if st.button("Entrar"):
        if ((df_usuarios["usuario"] == usuario) & (df_usuarios["contrasena"] == contrasena)).any():
            st.session_state.logged_in = True
            st.session_state.usuario = usuario
            st.success(f"✅ Bienvenido, {usuario}!")
            st.rerun()
        else:
            st.error("❌ Usuario o contraseña incorrectos")

    return False

# Verificar si está logueado
if "logged_in" not in st.session_state:
    st.session_state.logged_in = False

if not st.session_state.logged_in:
    login()
    st.stop()

# === SI ESTÁ LOGUEADO, MOSTRAR LA APP ===
st.sidebar.success(f"🟢 Sesión: {st.session_state.usuario}")
if st.sidebar.button("Cerrar sesión"):
    del st.session_state.logged_in
    del st.session_state.usuario
    st.rerun()

# Rutas base
base_dir = os.path.dirname(os.path.abspath(__file__))
data_dir = os.path.join(base_dir, "data")
resultados_dir = os.path.join(base_dir, "resultados")
historial_path = os.path.join(data_dir, "Historial_Completo.xlsx")

# Crear carpetas si no existen
os.makedirs(resultados_dir, exist_ok=True)
os.makedirs(data_dir, exist_ok=True)

# Cargar historial
if os.path.exists(historial_path):
    historial = pd.read_excel(historial_path)
else:
    historial = pd.DataFrame(columns=[
        "Ticket_ID", "Vendedor", "Fecha Desde", "Fecha Hasta", 
        "Monto Ticket", "Suma Banco", "Diferencia", "Estado", "Fecha Validación"
    ])

# Subir archivos
st.subheader("📤 Validar Nuevos Tickets")
uploaded_ops = st.file_uploader("1. Tabla Operaciones (Excel)", type="xlsx")
uploaded_tickets = st.file_uploader("2. Tickets a validar", type="xlsx")

if uploaded_ops and uploaded_tickets:
    if st.button("✅ VALIDAR NUEVOS TICKETS"):
        with st.spinner("Validando combinaciones exactas... Esto puede tardar unos segundos."):
            try:
                from validacion import validar_tickets

                resumen, detalle = validar_tickets(uploaded_tickets, uploaded_ops, historial, base_dir, tolerancia=10.0)

                # Guardar resultados
                ts = datetime.now().strftime("%Y%m%d_%H%M")
                out_file = os.path.join(resultados_dir, f"resultado_{ts}.xlsx")
                with pd.ExcelWriter(out_file, engine="xlsxwriter") as writer:
                    resumen.to_excel(writer, sheet_name="Resumen", index=False)
                    detalle.to_excel(writer, sheet_name="Detalle", index=False)

                # ✅ Actualizar y guardar historial
                try:
                    nuevo_historial = pd.concat([historial, resumen], ignore_index=True)
                    nuevo_historial.to_excel(historial_path, index=False)
                    st.success("✅ Historial actualizado correctamente.")
                except Exception as e:
                    st.error(f"❌ Error al guardar el historial: {str(e)}")

                st.balloons()
                st.success(f"✅ Validación completada. {len(resumen)} tickets procesados.")

                # Mostrar resumen
                st.subheader("📋 Resultado de la Validación")
                st.dataframe(resumen, use_container_width=True)

                # Mostrar historial (filtrado por vendedor)
                st.subheader("📁 Historial de Tickets Validados")
                if not nuevo_historial.empty:
                    vendedor_filter = st.selectbox(
                        "Filtrar por vendedor", 
                        ["Todos"] + nuevo_historial["Vendedor"].dropna().unique().tolist()
                    )
                    df_show = nuevo_historial if vendedor_filter == "Todos" else nuevo_historial[nuevo_historial["Vendedor"] == vendedor_filter]
                    st.dataframe(df_show, use_container_width=True)
                else:
                    st.info("Aún no hay tickets validados.")

                # Descargar resultados
                with open(out_file, "rb") as f:
                    st.download_button(
                        "📥 Descargar Resultados",
                        f.read(),
                        file_name=f"resultado_{ts}.xlsx",
                        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                    )

            except Exception as e:
                st.error(f"❌ Error al validar: {str(e)}")
                st.code(str(e), language="python")