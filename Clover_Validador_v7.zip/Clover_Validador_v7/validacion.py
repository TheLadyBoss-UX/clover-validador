import pandas as pd
from datetime import datetime
from itertools import combinations

def validar_tickets(uploaded_tickets, uploaded_ops, historial, base_dir, tolerancia=10.0):
    # Cargar datos
    df_tickets = pd.read_excel(uploaded_tickets, sheet_name="Tickets")
    df_ops = pd.read_excel(uploaded_ops, sheet_name="Tabla Operaciones")

    # Normalizar columnas Tickets
    col_fd = next(c for c in df_tickets.columns if "fecha" in c.lower() and "desde" in c.lower())
    col_fh = next(c for c in df_tickets.columns if "fecha" in c.lower() and "hasta" in c.lower())
    col_mt = next(c for c in df_tickets.columns if "monto" in c.lower())
    col_id = next((c for c in df_tickets.columns if "ticket" in c.lower()), None)

    df_tickets[col_fd] = pd.to_datetime(df_tickets[col_fd], dayfirst=True, errors='coerce')
    df_tickets[col_fh] = pd.to_datetime(df_tickets[col_fh], dayfirst=True, errors='coerce')

    # Normalizar columnas Operaciones
    if "FECHA DE PAGO" in df_ops.columns:
        fecha_col = "FECHA DE PAGO"
    else:
        raise KeyError("No encuentro columna de fecha (FECHA DE PAGO) en 'Tabla Operaciones'.")

    if "IMPORTE NETO" in df_ops.columns:
        importe_col = "IMPORTE NETO"
    else:
        raise KeyError("No encuentro columna de importe (IMPORTE NETO) en 'Tabla Operaciones'.")

    df_ops[fecha_col] = pd.to_datetime(df_ops[fecha_col], dayfirst=True, errors='coerce')
    df_ops[importe_col] = pd.to_numeric(df_ops[importe_col], errors='coerce')

    # Obtener operaciones YA USADAS en el historial
    ops_usadas = []
    for _, row in historial.iterrows():
        ops_rango = df_ops[
            (df_ops[fecha_col] >= row["Fecha Desde"]) &
            (df_ops[fecha_col] <= row["Fecha Hasta"])
        ]
        ops_usadas.extend(ops_rango.index.tolist())
    ops_usadas = list(set(ops_usadas))

    resumen = []
    detalles = []

    SUBSET_LIMIT = 20  # Máximo de operaciones para buscar subconjunto
    TOL = tolerancia   # Tolerancia en pesos

    for idx, t in df_tickets.iterrows():
        desde = t[col_fd]
        hasta = t[col_fh]
        esperado = float(t[col_mt]) if pd.notna(t[col_mt]) else 0.0
        ticket_id = t[col_id] if col_id else f"Ticket_{idx+1}"
        vendedor = t.get("Vendedor", "Desconocido")

        if pd.isna(desde) or pd.isna(hasta):
            continue

        # Filtrar operaciones por rango, excluyendo ya usadas
        ops = df_ops[
            (df_ops[fecha_col] >= desde) &
            (df_ops[fecha_col] <= hasta) &
            (~df_ops.index.isin(ops_usadas))
        ].copy()

        ops = ops.dropna(subset=[importe_col])
        suma_total = round(ops[importe_col].sum(), 2)
        diferencia = round(esperado - suma_total, 2)
        estado = "COINCIDE (suma total)" if abs(diferencia) < TOL else "NO COINCIDE"

        # Detalle base
        ops["Ticket_ID"] = ticket_id
        ops["Incluida_en_ticket"] = "No"

        subset_encontrado = False
        if abs(diferencia) >= TOL and 0 < len(ops) <= SUBSET_LIMIT:
            # Buscar subconjunto exacto
            valores = ops[importe_col].tolist()
            indices = list(ops.index)
            for r in range(1, len(valores)+1):
                found = False
                for comb_idx in combinations(range(len(valores)), r):
                    total = round(sum(valores[i] for i in comb_idx), 2)
                    if abs(total - esperado) < TOL:
                        ops.loc[ops.index[list(comb_idx)], "Incluida_en_ticket"] = "Sí"
                        subset_encontrado = True
                        estado = "COINCIDE (subconjunto)"
                        found = True
                        break
                if found:
                    break

        if subset_encontrado:
            suma_efectiva = round(ops.loc[ops["Incluida_en_ticket"]=="Sí", importe_col].sum(), 2)
        else:
            suma_efectiva = suma_total

        resumen.append({
            "Ticket_ID": ticket_id,
            "Vendedor": vendedor,
            "Fecha Desde": desde.date(),
            "Fecha Hasta": hasta.date(),
            "Monto Ticket": esperado,
            "Suma Banco": suma_total,
            "Diferencia": round(esperado - suma_efectiva, 2),
            "Estado": estado,
            "Fecha Validación": datetime.now().date()
        })

        detalles.append(ops[["Ticket_ID", fecha_col, "TARJETA", importe_col, "Incluida_en_ticket"]])

    df_resumen = pd.DataFrame(resumen)
    df_detalle = pd.concat(detalles, ignore_index=True) if detalles else pd.DataFrame()

    return df_resumen, df_detalle